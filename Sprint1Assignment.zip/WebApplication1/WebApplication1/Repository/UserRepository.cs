﻿using System.Collections.Generic;

namespace WebApplication1
{
    public class  UserRepository:IUserRepository
    {
        List<UserModel> UserModels = new List<UserModel>();

        public  List<UserModel> GetGetalluser()
        {

      
        

            return UserModels;

        }
       
       public void CreateUser(UserModel UserModel) {

                 UserModels.Add(UserModel);
          
        }
        public string UpdateUser(UserModel UserModel) {

            var result = UserModels.Find(x => x.Id == UserModel.Id);
            UserModels.RemoveAll(x => x.Id == UserModel.Id);
            UserModels.Add(UserModel);
            //   UserModels.Remove(x => x.id == UserModel.Id);
            string returnresult;
            if(result ==null)
            {
                returnresult = "failed";
            }
            else
            {
                returnresult = "success";
            }
            return returnresult;
        }

       public UserModel GetaUser(int id ) {

          var result=  UserModels.Find(x => x.Id == id);

        
            return result;

        }
    }
}