﻿using System.Collections.Generic;

namespace WebApplication1
{
    public class ProjectRepository : IProjectRepository
    {
        List<ProjectModel> lstProjectModel = new List<ProjectModel>();

    

        public void createproject(ProjectModel ProjectModel)
        {
            lstProjectModel.Add(ProjectModel);
        }

        public  List<ProjectModel> Getallproject()
        {

            
 

            return lstProjectModel;

        }

        public ProjectModel Getaproject(int id)
        {
            var result = lstProjectModel.Find(x => x.Id == id);


            return result;

        }

        public string Updateproject(ProjectModel ProjectModel)
        {
          

            var result = lstProjectModel.Find(x => x.Id == ProjectModel.Id);
            lstProjectModel.RemoveAll(x => x.Id == ProjectModel.Id);
            lstProjectModel.Add(ProjectModel);
            //   UserModels.Remove(x => x.id == UserModel.Id);
            string returnresult;
            if (result == null)
            {
                returnresult = "failed";
            }
            else
            {
                returnresult = "success";
            }
            return returnresult;
        }
    }
}