﻿using System.Collections.Generic;

namespace WebApplication1
{
    public class TaskRepository : ITaskRepository
    {
        List<TaskModel> lstTaskModel = new List<TaskModel>();

        public  List<TaskModel> GetallTasks()
        {


          

            //List<UserModel> UserModels = new List<UserModel>();

            //UserModel UserModel1 = new UserModel() { Id=10, FirstName="tst", LastName="Test",Email="test@test.com",Password="" };
            //UserModels.Add(UserModel1);



            return lstTaskModel;

        }

       public void CreateTask(TaskModel TaskModel)
        {

            lstTaskModel.Add(TaskModel);
        }
       public  string UpdateTask(TaskModel TaskModel)
       {
            var result = lstTaskModel.Find(x => x.Id == TaskModel.Id);
            lstTaskModel.RemoveAll(x => x.Id == TaskModel.Id);
            lstTaskModel.Add(TaskModel);
            //   UserModels.Remove(x => x.id == UserModel.Id);
            string returnresult;
            if (result == null)
            {
                returnresult = "failed";
            }
            else
            {
                returnresult = "success";
            }
            return returnresult;

        }
       public TaskModel GetaTask(int id)
       {
            var result = lstTaskModel.Find(x => x.Id == id);


            return result;

        }
    }
}