﻿using System.Collections.Generic;

namespace WebApplication1
{ 
    public interface ILoginrespository
    {
    string ValidateUser(string loginid, string password);

        
}
}